# Data

The repository does not include raw datasets unless redistribution is permitted.

The analysis expects the relevant source data to be placed in `data/raw/`.

Expected inputs include:

- `final_dataset.csv` — EuroLeague player/game statistics
- `QJE.dta` — QJE behavioral/cultural indicators
- `final_dataset_stats.csv` — player statistics required by the regression models
- `player_birthdates.csv` — player birth dates
- `player_heights.csv` — player heights
- `round_codes.csv` — round/phase information, where required

After running `01_data_preparation.R`, the processed analysis dataset is written to:

`data/processed/final_analysis_data.csv`
