# Packages used in the dissertation analysis

library(euroleaguer)
library(haven)
library(dplyr)
library(ggplot2)
library(stringr)
library(lubridate)
library(janitor)
library(countrycode)
library(modelsummary)
library(sandwich)
library(effects)
