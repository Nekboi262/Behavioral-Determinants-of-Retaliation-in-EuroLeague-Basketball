source("R/00_packages.R")

df <- read.csv("data/processed/final_analysis_data.csv")
load("results/models.RData")

# Model 1: patience and free-throw rate
pat_effect <- effect("patience_qje", model1)
png("figures/model1_patience_ft_rate.png", width = 900, height = 650)
plot(
  pat_effect,
  main = "",
  xlab = "Patience",
  ylab = "Predicted FT Rate"
)
dev.off()

# Model 2: steals × negative reciprocity
df$neg_group <- ifelse(
  is.na(df$negrecip), NA,
  ifelse(
    df$negrecip > median(df$negrecip, na.rm = TRUE),
    "High Negative Reciprocity",
    "Low Negative Reciprocity"
  )
)

df_plot <- df %>% filter(!is.na(neg_group))

p2 <- ggplot(
  df_plot,
  aes(x = steals, y = fouls_commited,
      color = neg_group, fill = neg_group)
) +
  geom_smooth(method = "lm", se = TRUE) +
  labs(
    x = "Steals",
    y = "Predicted Fouls Committed",
    color = "Negative Reciprocity",
    fill = "Negative Reciprocity"
  ) +
  theme_minimal(base_size = 14)

ggsave("figures/model2_steals_negative_reciprocity.png",
       p2, width = 8, height = 6)

# Model 3: risk-taking
risk_effect <- effect("risktaking", model3)
png("figures/model3_risk_taking.png", width = 900, height = 650)
plot(
  risk_effect,
  main = "",
  xlab = "Risktaking",
  ylab = "Predicted Fouls Committed"
)
dev.off()

# Model 4: patience and fouls received
pat_eff <- effect("patience_qje", model4)
png("figures/model4_patience_fouls_received.png", width = 900, height = 650)
plot(
  pat_eff,
  main = "",
  xlab = "Patience",
  ylab = "Predicted Fouls Received"
)
dev.off()

# Model 5: fouls received × negative reciprocity
p5 <- ggplot(
  df_plot,
  aes(x = fouls_received, y = fouls_commited,
      color = neg_group, fill = neg_group)
) +
  geom_smooth(method = "lm", se = TRUE) +
  labs(
    x = "Fouls Received",
    y = "Predicted Fouls Committed",
    color = "Negative Reciprocity",
    fill = "Negative Reciprocity"
  ) +
  theme_minimal(base_size = 14)

ggsave("figures/model5_retaliation_negative_reciprocity.png",
       p5, width = 8, height = 6)

# Model 6: three-way interaction
df2 <- df %>%
  filter(!is.na(negrecip), !is.na(patience_qje)) %>%
  mutate(
    neg_group = ifelse(
      negrecip > median(negrecip),
      "High NegRecip", "Low NegRecip"
    ),
    patience_group = case_when(
      patience_qje <= quantile(patience_qje, .33, na.rm = TRUE) ~
        "Low Patience",
      patience_qje <= quantile(patience_qje, .66, na.rm = TRUE) ~
        "Medium Patience",
      TRUE ~ "High Patience"
    )
  )

df2$pred <- predict(model6, df2)

p6 <- ggplot(
  df2,
  aes(x = fouls_received, y = pred,
      color = neg_group, fill = neg_group)
) +
  geom_smooth(method = "lm", se = TRUE) +
  facet_wrap(~ patience_group) +
  labs(
    x = "Fouls Received",
    y = "Predicted Fouls Committed",
    color = "Negative Reciprocity",
    fill = "Negative Reciprocity"
  ) +
  theme_minimal(base_size = 14)

ggsave("figures/model6_three_way_interaction.png",
       p6, width = 9, height = 6)

# Model 7: patience interaction
df_p <- df %>%
  filter(!is.na(patience_qje)) %>%
  mutate(
    pat_group = ifelse(
      patience_qje > median(patience_qje),
      "High Patience", "Low Patience"
    )
  )

df_p$pred <- predict(model7, df_p)

p7 <- ggplot(
  df_p,
  aes(x = fouls_received, y = pred,
      color = pat_group, fill = pat_group)
) +
  geom_smooth(method = "lm", se = TRUE) +
  labs(
    x = "Fouls Received",
    y = "Predicted Fouls Committed",
    color = "Patience Level",
    fill = "Patience Level"
  ) +
  theme_minimal(base_size = 14)

ggsave("figures/model7_patience_interaction.png",
       p7, width = 8, height = 6)

# Experience specification
newdata_exp <- expand.grid(
  fouls_received = seq(0, 12, length.out = 200),
  exp_group = c(
    "Non-veteran (≤5 seasons)",
    "Veteran (6+ seasons)"
  )
)

newdata_exp$turnovers <- mean(df$turnovers, na.rm = TRUE)
newdata_exp$minutes <- mean(df$minutes, na.rm = TRUE)
newdata_exp$patience_qje <- mean(df$patience_qje, na.rm = TRUE)
newdata_exp$age <- mean(df$age, na.rm = TRUE)
newdata_exp$height_cm <- mean(df$height_cm, na.rm = TRUE)

newdata_exp$pred <- predict(model_exp, newdata_exp)

p_exp <- ggplot(
  newdata_exp,
  aes(x = fouls_received, y = pred, color = exp_group)
) +
  geom_line(linewidth = 1.2) +
  labs(
    x = "Fouls Received",
    y = "Predicted Fouls Committed",
    color = "Experience Group"
  ) +
  theme_minimal(base_size = 14)

ggsave("figures/experience_interaction.png",
       p_exp, width = 8, height = 6)
