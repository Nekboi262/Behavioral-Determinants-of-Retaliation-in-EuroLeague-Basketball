source("R/00_packages.R")

# -------------------------------------------------------------------------
# DATA PREPARATION
# -------------------------------------------------------------------------
# Place the EuroLeague player/game dataset and QJE dataset in data/raw/.
# The original dissertation used EuroLeague data for 2016-17 through 2024-25
# and matched QJE cultural indicators to player nationality.

# Expected input objects/files:
#   final_dataset.csv  - EuroLeague player/game statistics
#   QJE.dta            - QJE patience and negative reciprocity indicators
#
# The original analysis also used EuroLeague player birth dates and heights.
# These can be collected with euroleaguer or supplied as intermediate files.

data <- read.csv("data/raw/final_dataset.csv")
qje <- read_dta("data/raw/QJE.dta")

# Keep dissertation seasons
data <- data %>%
  filter(season_code %in% paste0("E", 2016:2024))

# Player/game variables used in the analysis
data <- data %>%
  select(
    player, player_country, season_code, code, player_team, team_abbrv,
    fouls_commited, fouls_received, minutes, player_position,
    coach_name, coach_country
  ) %>%
  distinct()

# Convert game-code information to rounds where required.
# If round_codes.csv is supplied, it can be used to attach phase information.
if (file.exists("data/raw/round_codes.csv")) {
  round_codes <- read.csv("data/raw/round_codes.csv")
  names(round_codes)[4] <- "Round"

  data <- data %>%
    left_join(
      round_codes %>% select(Round, season_code, code, phase_type_alias),
      by = c("Round", "season_code", "code")
    )
}

# Join additional player statistics used by the dissertation models.
# This intermediate file should contain the variables below.
stats_file <- "data/raw/final_dataset_stats.csv"

if (file.exists(stats_file)) {
  data2 <- read.csv(stats_file)

  join_keys <- c("season_code", "Round", "team_abbrv", "player", "code")
  vars_to_add <- c(
    "points", "field_goals_made2", "field_goals_attempted2",
    "field_goals_made3", "field_goals_attempted3",
    "free_throws_made", "free_throws_attempted",
    "total_rebounds", "assistances", "steals", "turnovers"
  )

  join_keys <- intersect(join_keys, intersect(names(data), names(data2)))

  data <- data %>%
    mutate(across(all_of(join_keys), as.character)) %>%
    left_join(
      data2 %>%
        mutate(across(all_of(join_keys), as.character)) %>%
        select(any_of(c(join_keys, vars_to_add))) %>%
        distinct(across(all_of(join_keys)), .keep_all = TRUE),
      by = join_keys
    )
}

# Convert minutes from MM:SS to decimal minutes
convert_to_decimal_minutes <- function(time_str) {
  if (is.na(time_str) || time_str == "DNP") return(0)
  parts <- strsplit(time_str, ":")[[1]]
  as.numeric(parts[1]) + as.numeric(parts[2]) / 60
}

if (is.character(data$minutes)) {
  data$minutes <- sapply(data$minutes, convert_to_decimal_minutes)
}

# Standardize player names needed for matching
data <- data %>%
  mutate(
    player = case_when(
      player %in% c("GONZÁLEZ, HUGO", "GONZALEZ, HUGO") ~ "GONZALEZ, HUGO",
      player %in% c("MARÍ, LUCAS", "MARI, LUCAS") ~ "MARI, LUCAS",
      TRUE ~ player
    ),
    player_country = case_when(
      player == "GONZALEZ, HUGO" ~ "Spain",
      player == "MARI, LUCAS" ~ "Spain",
      player == "McCORMACK, DAVID" ~ "United States",
      TRUE ~ player_country
    ),
    player_country = countrycode(player_country, "country.name", "iso3c")
  )

# QJE cultural indicators
data <- data %>%
  left_join(qje, by = c("player_country" = "ISO3"))

# Birth dates / age
birth_file <- "data/raw/player_birthdates.csv"

if (file.exists(birth_file)) {
  birthdates <- read.csv(birth_file)

  data <- data %>%
    left_join(birthdates %>% select(player, birthdate),
              by = "player")

  data <- data %>%
    mutate(
      birthdate = as.Date(birthdate),
      season_year = as.numeric(substr(season_code, 2, 5)),
      season_start = ymd(paste0(season_year, "-10-01")),
      age = floor(time_length(interval(birthdate, season_start), "years"))
    ) %>%
    select(-birthdate, -season_year, -season_start)
}

# Player heights
height_file <- "data/raw/player_heights.csv"

if (file.exists(height_file)) {
  heights <- read.csv(height_file)

  data <- data %>%
    left_join(
      heights %>% select(player, height_cm) %>% distinct(),
      by = "player"
    )
}

# Variables used in the dissertation
data <- data %>%
  mutate(
    ft_rate = free_throws_made / free_throws_attempted
  )

# Experience: number of EuroLeague seasons played up to each season
data <- data %>%
  group_by(player) %>%
  arrange(season_code, .by_group = TRUE) %>%
  mutate(
    seasons_so_far = dense_rank(season_code),
    exp_group = ifelse(
      seasons_so_far > 5,
      "Veteran (6+ seasons)",
      "Non-veteran (≤5 seasons)"
    )
  ) %>%
  ungroup()

write.csv(data, "data/processed/final_analysis_data.csv", row.names = FALSE)
