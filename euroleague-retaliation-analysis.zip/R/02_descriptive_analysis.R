source("R/00_packages.R")

df <- read.csv("data/processed/final_analysis_data.csv")

# Distributions reported in the dissertation appendix
ggplot(df, aes(patience_qje)) +
  geom_histogram(bins = 30) +
  labs(x = "Patience", y = "Count") +
  theme_minimal(base_size = 14)

ggsave("figures/patience_distribution.png", width = 7, height = 5)

ggplot(df, aes(negrecip)) +
  geom_histogram(bins = 30) +
  labs(x = "Negative Reciprocity", y = "Count") +
  theme_minimal(base_size = 14)

ggsave("figures/negative_reciprocity_distribution.png", width = 7, height = 5)
