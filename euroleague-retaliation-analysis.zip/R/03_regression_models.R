source("R/00_packages.R")

df <- read.csv("data/processed/final_analysis_data.csv")

# -------------------------------------------------------------------------
# MODELS 1-9 FROM THE DISSERTATION
# -------------------------------------------------------------------------

model1 <- lm(
  ft_rate ~ patience_qje + total_rebounds + steals +
    turnovers + free_throws_attempted + minutes + height_cm + age + race,
  data = df
)

model2 <- lm(
  fouls_commited ~ steals * negrecip + turnovers +
    free_throws_attempted + minutes + height_cm + age + race,
  data = df
)

model3 <- lm(
  fouls_commited ~ risktaking + field_goals_made2 +
    field_goals_made3 + minutes + height_cm + age + race,
  data = df
)

model4 <- lm(
  fouls_received ~ patience_qje + field_goals_made2 +
    field_goals_made3 + minutes + height_cm + age + race,
  data = df
)

model5 <- lm(
  fouls_commited ~ negrecip * fouls_received +
    turnovers + field_goals_made2 + field_goals_made3 +
    minutes + height_cm + age + race,
  data = df
)

model6 <- lm(
  fouls_commited ~ fouls_received * negrecip * patience_qje +
    turnovers + minutes + height_cm + age + race,
  data = df
)

model7 <- lm(
  fouls_commited ~ fouls_received * patience_qje +
    negrecip + turnovers + minutes + height_cm + age + race,
  data = df
)

model8 <- lm(
  fouls_commited ~ fouls_received * negrecip +
    fouls_received * patience_qje +
    turnovers + minutes + height_cm + age + race,
  data = df
)

model9 <- lm(
  fouls_commited ~ fouls_received * patience_qje * age +
    turnovers + minutes + height_cm + race,
  data = df
)

# Experience specification used alongside Model 9
model_exp <- lm(
  fouls_commited ~ fouls_received * patience_qje * exp_group +
    turnovers + minutes + age + height_cm,
  data = df
)

# Cluster-robust variance estimate used as a robustness check
cluster_se_model1 <- vcovCL(model1, cluster = df$player_country)

# Save model objects
save(
  model1, model2, model3, model4, model5,
  model6, model7, model8, model9, model_exp,
  file = "results/models.RData"
)

# Regression tables
modelsummary(
  list(
    "Model 1" = model1,
    "Model 2" = model2,
    "Model 3" = model3,
    "Model 4" = model4
  ),
  stars = TRUE,
  statistic = "std.error",
  gof_map = c("nobs", "r.squared", "adj.r.squared"),
  title = "Regression Results",
  output = "results/models_1_4.tex"
)

modelsummary(
  list(
    "Model 5" = model5,
    "Model 6" = model6,
    "Model 7" = model7
  ),
  stars = TRUE,
  statistic = "std.error",
  gof_map = c("nobs", "r.squared", "adj.r.squared"),
  title = "Regression Results",
  output = "results/models_5_7.tex"
)

modelsummary(
  list(
    "Model 8" = model8,
    "Model 9" = model_exp
  ),
  stars = TRUE,
  statistic = "std.error",
  gof_map = c("nobs", "r.squared", "adj.r.squared"),
  title = "Regression Results",
  output = "results/models_8_9.tex"
)
